
// game options 
let options = ['rock', 'paper', 'scissors'];
let userChoice ;
let computerChoice;
let draw = false;

function rpsGame(e) {
    userChoice = e.id;
    computerChoice = options[Math.floor(Math.random() *3)];
    draw = false;

    // logic 
    if(userChoice == 'rock'){
        if(computerChoice == 'rock'){
            showDraw();
        } else if (computerChoice == 'paper'){
            showWinner('computer');
        } else if (computerChoice == 'scissors'){
            showWinner('human')
        }
    } else  if(userChoice == 'paper'){
        if(computerChoice == 'paper'){
            showDraw();
        } else if (computerChoice == 'scissors'){
            showWinner('computer');
        } else if (computerChoice == 'rock'){
            showWinner('human')
        }
    } else  if(userChoice == 'scissors'){
        if(computerChoice == 'scissors'){
            showDraw();
        } else if (computerChoice == 'rock'){
            showWinner('computer');
        } else if (computerChoice == 'paper'){
            showWinner('human')
        }
    }

}



function showWinner(winner){
    if(winner == 'computer') render('computer','red')
    else render('human', 'green')
}

function showDraw(){
    draw = true;
    render('draw', 'yellow')
}


function render (message,color){
   document.getElementById('paper').remove(); 
  
  //Let's create div for result display
  document.getElementById('scissors').alt = 'user choose:'+userChoice
  document.getElementById('rock').alt = 'computer choose:' +computerChoice

  let body = document.querySelector('body');

  draw == true ? body.innerHTML += 'No winner (DRAW)' : body.innerHTML += 'Winner is ' + message ;

}